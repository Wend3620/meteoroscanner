import matplotlib.pyplot as plt
import matplotlib.colors as mplc

class colorbars:
    def __init__(self, colorname):
        self.colorname = colorname